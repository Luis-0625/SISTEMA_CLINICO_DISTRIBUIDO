-- ============================================
-- 🔹 0. Preparación del esquema y extensiones
-- ============================================

CREATE SCHEMA IF NOT EXISTS hcd;
SET search_path TO hcd, public;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS citus;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================
-- 🔹 1. Tablas Catálogo (Reference tables)
-- ============================================

-- ISO3166
DROP TABLE IF EXISTS catalogo_iso3166 CASCADE;
CREATE TABLE catalogo_iso3166 (
    code VARCHAR(3) PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);
INSERT INTO catalogo_iso3166 (code, name) VALUES
('CO','Colombia'),('US','Estados Unidos'),('BR','Brasil'),('AR','Argentina'),
('MX','México'),('CL','Chile'),('PE','Perú'),('ES','España'),('FR','Francia'),('DE','Alemania');
SELECT create_reference_table('catalogo_iso3166');

-- UCUM
DROP TABLE IF EXISTS catalogo_ucum CASCADE;
CREATE TABLE catalogo_ucum (
    code VARCHAR(20) PRIMARY KEY,
    description VARCHAR(120) NOT NULL
);
INSERT INTO catalogo_ucum (code, description) VALUES
('mg','milligram'),('g','gram'),('mL','milliliter'),('L','liter'),
('IU','international unit'),('h','hour'),('d','day'),
('kg','kilogram'),('mcg','microgram'),('tab','tablet');
SELECT create_reference_table('catalogo_ucum');

-- CIE10
DROP TABLE IF EXISTS catalogo_cie10 CASCADE;
CREATE TABLE catalogo_cie10 (
    codigo VARCHAR(8) PRIMARY KEY,
    descripcion VARCHAR(255) NOT NULL
);
INSERT INTO catalogo_cie10 (codigo, descripcion) VALUES
('A00','Cólera'),('B20','Enfermedad por VIH'),('E11','Diabetes mellitus tipo 2'),
('I10','Hipertensión esencial (primaria)'),('J45','Asma'),
('K21','Reflujo gastroesofágico'),('N39','Trastornos del tracto urinario'),
('O80','Parto único espontáneo'),('S06','Traumatismo intracraneal'),
('Z00','Examen general sin diagnóstico');
SELECT create_reference_table('catalogo_cie10');

-- SNOMED
DROP TABLE IF EXISTS catalogo_snomed CASCADE;
CREATE TABLE catalogo_snomed (
    concept_id VARCHAR(20) PRIMARY KEY,
    term VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL
);
INSERT INTO catalogo_snomed (concept_id, term, category) VALUES
('26643006','Vía oral','route'),
('46713006','Vía intravenosa','route'),
('78421000','Vía intramuscular','route'),
('91936005','Alergia a penicilina','allergy'),
('235595009','Procedimiento de administración','procedure');
SELECT create_reference_table('catalogo_snomed');

-- ============================================
-- 🔹 2. Roles del Sistema
-- ============================================

DROP TABLE IF EXISTS rol CASCADE;
CREATE TABLE rol (
    rol_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre_rol VARCHAR(50) UNIQUE NOT NULL,
    descripcion TEXT
);
INSERT INTO rol (nombre_rol, descripcion) VALUES
('Administrador', 'Tiene acceso total al sistema'),
('Medico', 'Puede registrar, editar y consultar historias clínicas'),
('Enfermero', 'Puede consultar historias clínicas y registrar signos vitales'),
('Recepcionista', 'Puede registrar nuevos pacientes y gestionar citas'),
('Paciente', 'Puede consultar su información médica personal');
SELECT create_reference_table('rol');

-- ============================================
-- 🔹 3. Usuarios (Pacientes)
-- ============================================

DROP TABLE IF EXISTS usuario CASCADE;
CREATE TABLE usuario (
    documento_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_documento VARCHAR(20), -- CC real
    pais_nacionalidad VARCHAR(3) NOT NULL,
    nombre_completo VARCHAR(255) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    edad INT,
    sexo VARCHAR(10) NOT NULL,
    genero VARCHAR(20),
    ocupacion VARCHAR(100),
    voluntad_anticipada BOOLEAN DEFAULT FALSE,
    categoria_discapacidad VARCHAR(50),
    pais_residencia VARCHAR(3),
    municipio_residencia VARCHAR(100),
    etnia VARCHAR(50),
    comunidad_etnica VARCHAR(100),
    zona_residencia VARCHAR(50),
    CONSTRAINT chk_usuario_sexo CHECK (sexo IN ('M','F','Intersex')),
    CONSTRAINT chk_usuario_zona CHECK (zona_residencia IS NULL OR zona_residencia IN ('Urbana','Rural','Dispersa')),
    CONSTRAINT fk_usuario_pais_nacionalidad FOREIGN KEY (pais_nacionalidad) REFERENCES catalogo_iso3166(code),
    CONSTRAINT fk_usuario_pais_residencia FOREIGN KEY (pais_residencia) REFERENCES catalogo_iso3166(code)
);
CREATE INDEX idx_usuario_nombre ON usuario(nombre_completo);
SELECT create_reference_table('usuario');

-- ============================================
-- 🔹 4. Login / Autenticación
-- ============================================

DROP TABLE IF EXISTS login_usuario CASCADE;
CREATE TABLE login_usuario (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre_usuario VARCHAR(100) UNIQUE NOT NULL, -- será CC real
    contrasena VARCHAR(255) NOT NULL,
    correo VARCHAR(150) UNIQUE,
    rol_id UUID NOT NULL,
    documento_id UUID,
    activo BOOLEAN DEFAULT TRUE,
    ultimo_login TIMESTAMP,
    creado_en TIMESTAMP DEFAULT NOW(),
    actualizado_en TIMESTAMP DEFAULT NOW(),
    CONSTRAINT fk_login_rol FOREIGN KEY (rol_id) REFERENCES rol(rol_id),
    CONSTRAINT fk_login_usuario FOREIGN KEY (documento_id) REFERENCES usuario(documento_id)
);
SELECT create_reference_table('login_usuario');

-- ============================================
-- 🔹 5. Actualizar login_usuario con CC real
-- ============================================

UPDATE hcd.login_usuario lu
SET nombre_usuario = u.numero_documento
FROM hcd.usuario u
WHERE lu.documento_id = u.documento_id
  AND lu.rol_id = (SELECT rol_id FROM hcd.rol WHERE nombre_rol = 'Paciente');

-- ============================================
-- 🔹 6. Atención Médica, Diagnóstico, Tecnología, Egreso, Historia Clínica
-- (idem script original, manteniendo UUIDs)
-- ============================================

-- Aquí siguen todas las tablas de atención, diagnostico, tecnologia_salud, egreso, historia_clinica
-- con id UUID y documento_id como FK hacia usuario(documento_id)
-- No es necesario tocar nada más, las relaciones se mantienen consistentes

